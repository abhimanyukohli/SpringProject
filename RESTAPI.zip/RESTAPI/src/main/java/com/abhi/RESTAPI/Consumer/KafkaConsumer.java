package com.abhi.RESTAPI.Consumer;

import com.abhi.RESTAPI.Model.UserKafka;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@Service
public class KafkaConsumer {
    @Autowired
    UserKafka userActivity;

    @Bean
    public UserKafka getUserActivity() {
        return new UserKafka();
    }

    @Autowired
    private String kafkaTopic;

  @Autowired
  RestTemplate restTemplate;

    @Bean
    public RestTemplate getRestTemplate() {
        RestTemplate rt = new RestTemplate();
       return rt;
    }

    @KafkaListener(topics = "rApi_topic", groupId = "gId_Kafka01")
    public void receive(ConsumerRecord record) {
        System.out.println(String.format("Topic - %s, Partition - %d, Value: %s", kafkaTopic, record.partition(), record.value()));
        System.out.println(record.value());

        ObjectMapper mapper = new ObjectMapper();

//JSON from String to Object
        String jsonString= (String)record.value();
            try {
                UserKafka user = mapper.readValue(jsonString, UserKafka.class);
                //System.out.println("User Activity :"+user.getActivity());
                final String baseUrl = "http://localhost:8080//bankOfUniverse/displayUser/";
                URI uri = new URI(baseUrl);
                RestTemplate restTemplate = new RestTemplate();
                 HttpEntity<UserKafka> request = new HttpEntity<>(user);
                 ResponseEntity<UserKafka> response = restTemplate
                  .exchange(uri, HttpMethod.POST, request,UserKafka.class);
                   //.exchange(uri, HttpMethod.POST, request,UserKafka.class);
             System.out.println("Post request is successfully invoked");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
        //Convert JSON to Java object
        ObjectMapper mapper = new ObjectMapper();
    @Bean
    public String getKafkaTopic() {
        kafkaTopic="rApi_topic";
        return kafkaTopic;
    }


    public void receive(UserKafka userKafka) {
    }
}

