package com.abhi.RESTAPI.Repository;

public class UserRepos {
}
