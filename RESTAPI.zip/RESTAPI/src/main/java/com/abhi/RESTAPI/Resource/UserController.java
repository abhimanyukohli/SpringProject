package com.abhi.RESTAPI.Resource;

import com.abhi.RESTAPI.Consumer.KafkaConsumer;
import com.abhi.RESTAPI.Model.UserKafka;
import com.abhi.RESTAPI.Producer.KafkaProducer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value="/bankOfUniverse")
public class UserController {
    @Autowired
    KafkaProducer kafkaSender;

    @Autowired
    KafkaConsumer kafkareceiver;
    UserKafka userKafka;
    @PostMapping("/addJSONMsg")

    public String addJSONMsg(@RequestBody UserKafka userKafka) throws JsonProcessingException {

        kafkaSender.send(userKafka);
        ObjectMapper mp = new ObjectMapper();
        String returnString = "";
        try {
            System.out.println("returnString ... " + returnString);
            returnString = mp.writeValueAsString("Added Successfully");
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return returnString;
    }
    ObjectMapper mp = new ObjectMapper();
    String returnString = "";


    @PostMapping(value = "/displayUser")
    public UserKafka addUser(@RequestBody UserKafka userKafka) throws JsonProcessingException {
       try {

            returnString = mp.writeValueAsString("REST API invoked");
            System.out.println("returnString ... " + returnString);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }


}


