package com.abhi.RESTAPI.Producer;

import com.abhi.RESTAPI.Model.UserKafka;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducer {
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    String kafkaTopic = "rApi_topic";

    public String convertJsonString(UserKafka data){

        ObjectMapper mapper = new ObjectMapper();
        // User user = new User();
        String jsonInString="";

//Object to JSON in String
        try {
            jsonInString = mapper.writeValueAsString(data);
            System.out.println("Data value Now:1= " + data.toString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return jsonInString;
    }

    public void send(UserKafka data) throws JsonProcessingException {
       // System.out.println("Data value Now:2 = " + data.toString());
        String jsonString= convertJsonString(data);
        ObjectMapper mapper = new ObjectMapper();
        UserKafka user = mapper.readValue(jsonString, UserKafka.class);
        String activity   = user.getActivity();

        //    System.out.println("String Info" + jsonString.toString());
            kafkaTemplate.send(kafkaTopic, jsonString);
            kafkaTemplate.flush();
            System.out.println("data sent to kafka");
        }
    }


